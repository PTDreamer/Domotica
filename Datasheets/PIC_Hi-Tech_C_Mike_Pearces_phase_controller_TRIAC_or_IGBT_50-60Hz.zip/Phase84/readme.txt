> -----Original Message-----
> From: Mike Pearce [mailto:mimemike@paradise.net.nz]
> Sent: Wednesday, 11 July 2001 4:28 p.m.
> To: Shane
> Subject: The Attached File
> Importance: High
>
> The attached file is a single channel phase controller for a PIC16x84 @ 10Mhz.
> It includes all versions of the code, plus schematic in protel 99 binary and
> jpg formats.
>
> V0.0.0 - uses PORTB as a 7 bit input (0-128)
>
> V0.0.1 - uses 2 pins on PORTB to Increase/Decrease the level.
> This is checked every 10ms - only done for a quict test.
>
> V0.0.2 is the version that matches the circuit diagram, and by using the
> #defines can select input and output options.
>
> RB0/INT is used for the zero cross detection.
>
> RA0 is an active LOW output to an opto isolator to drive a TRIAC or IGBT
> circuit.
>
> Phase control is a simple even time-slice method, with 255 levels of output.
>
> This has samples of how to use the interrupt routine for TMR0 and INT.
>
> Should be easy for people to modify the main loop to suit there own needs.
>
> Timing for 50Hz and 60Hz has been included - selectable by commenting out the
> unwanted option.
>
> Also TRIAC or IGBT output is avalaible by commenting out the unwanted option.
>
> There is more info in the c file pertaining to TRIAC/IGBTS and EMI standards.
>
> P.S. - It worked on the first compile :) How often does that happen?????
>
> Mike :)

--- from phase84.c ---

* Simple Phase control using  PIC16F84 - 100% C Program.
* Using even time slicing method for both Triac and IGBT Drive methods.
* Just change specific #define to choose which method is in use.
*
* Output pin for phase ctrl is RA0
* Zero Cross input is RB0
* Remainder of PORTB is used for level setting 0 to 255 in incs of 2
*
* Output is Active LOW - i.e. it is desigend to pull an LEDs Cathode in an
* opto-coupler low to turn the output ON.
*
* Output Driver Types:
* Either TRIAC or IGBT control can be used with this software by selecting
* the appropiate #define command.
*
* IGBT Driver:
* An IGBT driver turns the output ON at the zero cross point and turns
* the output OFF part way through the cycle - this has really low
* EMI properties and is one of the few methods allowed for phase control
* in European countrys (i.e complies with EN55015 EMI standard).
* Other countries are following suit for example New Zealand and Austrailia
* are almost there (See AS/NZS 4051 and CISPR15 EMI Standards )
* This method of dimming is audibly quiet, does not require extra filter
* componets (If designed properly).It also has a better lamp life and can
* control a wider range of lamps than the TRIAC method of dimming.
*
* TRIAC Driver:
* A TRIAC driver turns the output OFF at the zero-cross and turns the
* output ON part way through the cycle - this has high EMI output and needs
* filter inducors etc. This has been the most popular method of phase
* control since it was first demonstraited in London in 1962. To make
* the TRIAC dimmer complient with modern EMI standards it requires
* carefully designed filter circuits using large Toroid Inductors
* and mains voltage AC rated capacitors.
* This is still the simplest method to do, and quite cheap, but not
* recommended for comercial designs any more.
* It also has a tendancy to reduce Lamp life, and creates alot of audiable
* noise in both the inductors and lamps.

--- end ---