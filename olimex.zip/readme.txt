1. Name: Jose Barros

2. Company: FAP

3. Billing address: Rua Jose Maria Pedroto N-12, 1E, Sto.Antonio, 2825-439 Costa de Caparica, PORTUGAL

4. Shipping address: Rua Jose Maria Pedroto N-12, 1E, Sto.Antonio, 2825-439 Costa de Caparica, PORTUGAL

5. Shipping option: AIRMAIL 

6. Order: DSS 3 pce of board in file "LUZES_18Fv3.brd + DSS 1 pce of board in file "olimex.brd"

7. For all orders from Europe Union: 600010686.

8. Payment option: Paypal

9. De-panelization with smooth or rough borders (read our FAQ for panelization to learn what does this means)

10. Notes: nill